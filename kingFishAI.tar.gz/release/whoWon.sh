#!/bin/bash
tail -n 1 p1.log
