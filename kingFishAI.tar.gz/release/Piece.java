
public class Piece {
	public int r;
	public int c;
	
	public Piece(int x, int y){
		r=x;
		c=y;
	}
}
