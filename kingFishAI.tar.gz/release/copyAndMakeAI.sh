#!/bin/bash
./copyAI.sh
make
